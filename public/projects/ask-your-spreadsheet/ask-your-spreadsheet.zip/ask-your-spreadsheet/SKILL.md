---
name: ask-your-spreadsheet
description: Use when someone shares a spreadsheet (xlsx, csv, Google Sheet export) and asks a question about it. Checks the sheet, uses its definitions, and answers with a trace they can verify.
---

# Ask your spreadsheet, and trust the answer

The person is not technical. They want a correct answer they can check, in plain language. Follow these steps in order. Keep every reply short and scannable.

## 1. Protect people first

Before anything else, scan the columns for personal details: names, emails, phone numbers, street addresses, ID numbers, dates of birth, health or financial details.

- If you find any, say so in one sentence and ask whether their organization allows this data in Claude. Suggest removing those columns, since questions about counts and trends rarely need them.
- Never repeat personal details back in an answer. Report counts and groups, not individuals, unless they explicitly ask about one record they own.

## 2. Check the shape

Read every sheet. Then check for the problems that cause wrong answers, and list only the ones you find:

- More than one header row, merged cells, or a title above the headers.
- Total or subtotal rows mixed in with the data.
- Blank rows in the middle.
- Duplicate records.
- The same value written different ways ("Monthly", "monthly", "Mo.").
- Dates stored as text, or in mixed formats.
- Text like "n/a" in a number column.

If there are problems, say what you will do about each one (for example "I'll treat 'Mo.' as Monthly and skip the TOTAL row") before answering, so they can object. Suggest fixing the sheet itself for next time.

## 3. Find or agree the definitions

Look for a tab named Definitions, Glossary, or similar, and use it exactly.

If the question uses a word that isn't defined there ("active", "new", "lapsed", "engaged", "customer", "on time"), do not guess silently. Propose a definition in one line, using the sheet's columns, and ask them to confirm or change it. If they're not available to answer, state the definition you used at the top of the answer.

Offer to write the agreed definitions as a Definitions tab they can paste into the sheet, so the next answer uses the same rules.

## 4. Sharpen the question

Restate the question in one sentence that settles: who or what is counted, over what time period, and compared with what. Example: "Active members (paid in the 12 months to Oct 31, 2026), compared with lapsed members, by town."

## 5. Answer with a trace

Do the calculation with code, never by estimating. Then give the answer in these layers:

1. **Answer:** one sentence with the number.
2. **What was counted:** the definitions used and how many rows.
3. **What was left out:** rows skipped, duplicates removed, values that couldn't be read.
4. **Where it came from:** which sheet and columns.
5. **How it was calculated:** the steps or formula, kept short; offer the code if they want it.

If the question compares groups, add one line: this shows a difference, not its cause.

## 6. Check against known answers

If the workbook has a Checks tab (questions with known answers), answer those first and report whether you matched them. If you didn't match, stop and work out why before answering anything new.

If there is no Checks tab, suggest they write down two or three questions they already know the answers to, so they can test any future answer.

## 7. Make it repeatable

At the end of the first conversation about a sheet, offer once to write a short "instructions for next time" note: the definitions, the clean-up rules, and the checks. Suggest they save it with the sheet, or in a Claude Project, so next month's answers use the same rules.
